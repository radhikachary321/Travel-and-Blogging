const express = require('express');
const app = express();
const path = require('path');

// Serve static files from public folder
app.use(express.static('public'));

// Route for login.html
app.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

// Route for signup.html
app.get('/signup.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'signup.html'));
});

// Route for home.html
app.get('/home.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'home.html'));
});

// Start server
app.listen(3000, () => {
  console.log('Server is running at http://localhost:3000');
});
