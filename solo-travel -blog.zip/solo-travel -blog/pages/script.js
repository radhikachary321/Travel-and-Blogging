const placesData = {
  goa: {
    name: "Goa, India",
    overview: "Goa is a coastal paradise known for its sun-kissed beaches, Portuguese heritage, water sports, nightlife, and vibrant culture.",
    placesToVisit: [
      "Baga Beach",
      "Fort Aguada",
      "Dudhsagar Falls",
      "Anjuna Beach",
      "Basilica of Bom Jesus"
    ],
    hotels: [
      "Taj Exotica Resort", "ITC Grand Goa", "Zostel Goa", "W Goa", "Cidade de Goa"
    ],
    thingsToDo: [
      "Jet skiing and parasailing",
      "Attend Sunburn music festival",
      "Sunset cruise on Mandovi River",
      "Scuba diving at Grande Island",
      "Shopping at Mapusa market"
    ],
    flights: [
      "Delhi to Goa – 2h 30m (₹3,000)", 
      "Mumbai to Goa – 1h (₹1,500)", 
      "Bangalore to Goa – 1h 15m (₹2,000)"
    ],
    food: [
      "Fish curry rice",
      "Prawn Balchão",
      "Xacuti chicken",
      "Bebinca dessert",
      "Feni – traditional local drink"
    ],
    restaurants: [
      "Thalassa – Greek cuisine with sea view",
      "Martin's Corner – Goan seafood",
      "Fisherman’s Wharf – riverside dining",
      "Vinayak Family Restaurant – local favorite",
      "Burger Factory – casual beach eats"
    ]
  },
  jaipur: {
    name: "Jaipur, Rajasthan",
    overview: "Jaipur is the Pink City of India, rich in royal heritage, majestic forts, colorful bazaars, and traditional Rajasthani cuisine.",
    placesToVisit: [
      "Amber Fort",
      "City Palace",
      "Hawa Mahal",
      "Nahargarh Fort",
      "Jantar Mantar"
    ],
    hotels: [
      "Rambagh Palace",
      "Trident Jaipur",
      "Pearl Palace Heritage",
      "ITC Rajputana",
      "Taj Jai Mahal"
    ],
    thingsToDo: [
      "Camel ride at Jal Mahal",
      "Light & Sound show at Amber Fort",
      "Shopping in Bapu Bazaar",
      "Enjoy Rajasthani thali at Chokhi Dhani",
      "Attend Jaipur Literature Festival"
    ],
    flights: [
      "Delhi to Jaipur – 1h (₹1,200)",
      "Mumbai to Jaipur – 2h (₹2,500)",
      "Hyderabad to Jaipur – 2h 15m (₹2,800)"
    ],
    food: [
      "Laal Maas",
      "Dal Baati Churma",
      "Ghewar",
      "Pyaaz Kachori",
      "Rabri"
    ],
    restaurants: [
      "Laxmi Mishthan Bhandar – sweets & snacks",
      "Tapri Central – tea & fusion café",
      "1135 AD – royal dining inside Amber Fort",
      "Suvarna Mahal – fine dining",
      "Chokhi Dhani Restaurant – cultural experience"
    ]
  }
};

function searchPlace() {
  const input = document.getElementById("searchInput").value.toLowerCase().trim();
  const resultDiv = document.getElementById("results");
  const data = placesData[input];

  resultDiv.innerHTML = ""; // clear old results

  if (!data) {
    resultDiv.innerHTML = `<h2>No data found for "${input}". Try Goa or Jaipur.</h2>`;
    return;
  }

  resultDiv.innerHTML = `
    <h2>${data.name}</h2>
    <div class="section"><h3>Overview</h3><p>${data.overview}</p></div>
    <div class="section"><h3>Places to Visit</h3><ul>${data.placesToVisit.map(p => `<li>${p}</li>`).join('')}</ul></div>
    <div class="section"><h3>Hotels</h3><ul>${data.hotels.map(h => `<li>${h}</li>`).join('')}</ul></div>
    <div class="section"><h3>Things to Do</h3><ul>${data.thingsToDo.map(t => `<li>${t}</li>`).join('')}</ul></div>
    <div class="section"><h3>Flight Timings</h3><ul>${data.flights.map(f => `<li>${f}</li>`).join('')}</ul></div>
    <div class="section"><h3>Famous Foods</h3><ul>${data.food.map(f => `<li>${f}</li>`).join('')}</ul></div>
    <div class="section"><h3>Restaurants Available</h3><ul>${data.restaurants.map(r => `<li>${r}</li>`).join('')}</ul></div>
  `;
}
