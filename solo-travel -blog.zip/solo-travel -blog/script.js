function signUp() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
  
    if (!name || !email || !password) {
      alert("Please fill in all fields.");
      return;
    }
  
    const users = JSON.parse(localStorage.getItem("users")) || [];
  
    const userExists = users.some((user) => user.email === email);
    if (userExists) {
      alert("Email already registered. Please login.");
      return;
    }
  
    users.push({ name, email, password });
    localStorage.setItem("users", JSON.stringify(users));
    alert("Signup successful! Please login.");
    window.location.href = "login.html";
  }
  
  function login() {
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;
  
    const users = JSON.parse(localStorage.getItem("users")) || [];
  
    const validUser = users.find(
      (user) => user.email === email && user.password === password
    );
  
    if (validUser) {
      localStorage.setItem("currentUser", JSON.stringify(validUser));
      window.location.href = "home.html";
    } else {
      document.getElementById("error").innerText = "Invalid email or password!";
    }
  }
  